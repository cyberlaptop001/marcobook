import React from "react";

export default function App() {
  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold text-blue-600">💼 Marco Book</h1>
      <p className="mt-4 text-gray-700">TailwindCSS is working — Let's build your cashbook clone!</p>
    </div>
  );
}
